from django.utils.translation import gettext as _

string = _("This app has no locale directory")
