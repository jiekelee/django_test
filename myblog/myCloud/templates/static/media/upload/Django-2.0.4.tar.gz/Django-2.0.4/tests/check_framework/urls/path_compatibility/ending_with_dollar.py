from django.urls import path

urlpatterns = [
    path('ending-with-dollar$', lambda x: x),
]
