from django.utils.translation import gettext as _

string = _("This app has a locale directory")
